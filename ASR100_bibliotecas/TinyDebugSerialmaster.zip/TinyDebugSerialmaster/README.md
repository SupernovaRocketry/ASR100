TinyDebugSerial
---------------

Break out of tiny software serial library from 
[arduino-tiny](https://code.google.com/p/arduino-tiny/) core.

Compatible with DA Mellis's newer
[ATtiny core](https://github.com/damellis/attiny/tree/ide-1.6.x).
